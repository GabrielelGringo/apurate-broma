@echo off
cd /d "%~dp0"
title Pet Land - Uber Envios Bridge
py bridge.py
pause
