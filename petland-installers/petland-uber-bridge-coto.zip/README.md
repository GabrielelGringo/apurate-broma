# Pet Land — Uber Envios Bridge

Mini-servicio que corre en la PC de cada sucursal y orquesta el envío vía Uber Flash sin que el cajero tenga que cargar nada en uber.com.

## Cómo encaja en el sistema

```
POS Odoo               Bridge (PC sucursal)            Uber.com           Sofia
───────────────        ──────────────────              ────────           ────────
1. Cajero aprieta      
   "Enviar con Uber"   
        │              
        ▼              2. Recibe POST /solicitar
   POST /uber/                con cliente, dirección,  
   envio/solicitar            monto, regla cobro
                              │
                              ▼
                       3. Abre Chrome con
                          uber.com precargado
                              │
                              ▼ (cajero confirma)        
                       4. Detecta tracking link
                          en URL/DOM
                              │
                              ▼
                   POST /uber/envio/callback
                              │
                              ▼                                          
   5. Odoo guarda link  ──────────────────────────────────►  6. WhatsApp al
      tracking                                                  cliente con link
```

## Instalación en PC de sucursal

1. Copiar esta carpeta a `C:\PetlandBridge\` (o donde quieras).
2. Editar `config.json` con el nombre de la sucursal y la URL pública del Odoo.
3. Ejecutar `install.bat` como administrador.
4. Correr `run.bat` una vez. Se abrirá Chrome controlado.
5. En esa ventana, loguear `m.uber.com` con la cuenta de Pet Land. La sesión queda guardada.
6. Cerrar Chrome. El bridge ya arranca automático en cada inicio de sesión.

## Endpoints

| Endpoint | Método | Uso |
|----------|--------|-----|
| `/health` | GET | Healthcheck |
| `/solicitar` | POST | Recibe envío desde Odoo. Encola y procesa. |
| `/cancelar` | POST | Quita un envío de la cola si todavía no se procesó. |

## Configuración por sucursal en Odoo

En Odoo > Punto de Venta > Configuración > [sucursal]:

- **Habilitar envíos Uber**: ON
- **URL del bridge local**: `http://192.168.x.x:5005` (IP local de la PC de la sucursal)
- **Dirección fija de origen**: dirección exacta del local

## Logs

`bridge.log` en la misma carpeta. Rotación manual.

## Seguridad

- El bridge solo escucha en la red local de la sucursal.
- No acepta credenciales por API: la sesión Uber está guardada en `chrome_profile/` y se mantiene mientras nadie deslogue manualmente.
- No hay datos de tarjeta — todo lo maneja Uber del lado server.
