@echo off
REM ===================================================================
REM Pet Land - Uber Envios Bridge - Instalador todo-en-uno
REM Doble click y listo. No requiere conocimientos tecnicos.
REM ===================================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo  =========================================================
echo   PET LAND - INSTALADOR ENVIOS UBER (sucursal Coto)
echo  =========================================================
echo.
echo  Esto va a tardar entre 3 y 8 minutos. No cierres la ventana.
echo.
pause

REM ---------- 1. Verificar Python ----------
echo.
echo [1/5] Verificando Python...
py --version >nul 2>&1
if errorlevel 1 (
    echo   Python no esta instalado. Bajando instalador...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python-installer.exe'"
    if errorlevel 1 goto error_python
    echo   Instalando Python (puede tardar 2 min)...
    "%TEMP%\python-installer.exe" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
    if errorlevel 1 goto error_python
    echo   Python instalado. Refrescando PATH...
    set "PATH=%PATH%;%ProgramFiles%\Python312;%ProgramFiles%\Python312\Scripts"
)
py --version
if errorlevel 1 goto error_python

REM ---------- 2. Dependencias Python ----------
echo.
echo [2/5] Instalando dependencias (flask, requests, playwright)...
py -m pip install --upgrade pip --quiet
py -m pip install -r requirements.txt --quiet
if errorlevel 1 goto error_pip

REM ---------- 3. Chromium para Playwright ----------
echo.
echo [3/5] Bajando Chromium controlado (es independiente del Chrome del local)...
py -m playwright install chromium
if errorlevel 1 goto error_pw

REM ---------- 4. Tarea programada de arranque ----------
echo.
echo [4/5] Configurando arranque automatico al prender la PC...
schtasks /Create /F /SC ONLOGON /RL HIGHEST /TN "PetLandUberBridge" ^
  /TR "cmd /c cd /d \"%~dp0\" && py bridge.py" >nul 2>&1
if errorlevel 1 echo   (aviso) No pude crear la tarea programada. Despues la creas a mano.

REM ---------- 5. Abrir para loguear Uber ----------
echo.
echo [5/5] Ahora se va a abrir Chrome controlado para loguear m.uber.com.
echo.
echo   IMPORTANTE:
echo     - Logueate con la cuenta de Pet Land (la que tiene la tarjeta cargada).
echo     - Marca la opcion "mantener sesion iniciada".
echo     - Cuando termines, cerra la ventana del Chrome.
echo.
pause
py login_uber.py

echo.
echo  =========================================================
echo   LISTO. EL BRIDGE QUEDA INSTALADO Y ARRANCARA SOLO.
echo  =========================================================
echo.
echo   Para arrancarlo ahora: doble click en "run.bat".
echo.
pause
exit /b 0

:error_python
echo.
echo  ERROR instalando Python. Avisar a soporte.
pause
exit /b 1

:error_pip
echo.
echo  ERROR instalando dependencias. Avisar a soporte.
pause
exit /b 1

:error_pw
echo.
echo  ERROR bajando Chromium. Avisar a soporte.
pause
exit /b 1
