"""Abre Chrome controlado para que el operador loguee m.uber.com.
La sesion queda guardada en chrome_profile/ y la usa el bridge despues."""

from pathlib import Path
from playwright.sync_api import sync_playwright

PROFILE = Path(__file__).parent / "chrome_profile"
PROFILE.mkdir(exist_ok=True)

with sync_playwright() as p:
    ctx = p.chromium.launch_persistent_context(
        user_data_dir=str(PROFILE),
        headless=False,
        channel="chrome",
        viewport={"width": 1280, "height": 820},
    )
    page = ctx.pages[0] if ctx.pages else ctx.new_page()
    page.goto("https://m.uber.com/")
    print("\n[ Loguea m.uber.com con la cuenta de Pet Land y cerra la ventana cuando termines ]\n")
    try:
        # Espera hasta que el usuario cierre la ventana
        ctx.wait_for_event("close", timeout=0)
    except Exception:
        pass
