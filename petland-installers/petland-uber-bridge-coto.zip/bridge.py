"""
Pet Land - Uber Envios Bridge
==============================
Mini-servicio que corre en la PC de cada sucursal.

Flujo:
  1. Recibe POST /solicitar desde Odoo con datos del envio.
  2. Abre Chrome con Playwright (sesion persistente, mantiene login Uber).
  3. Navega a uber.com/send/ con origen y destino precargados.
  4. El cajero revisa y aprieta "Solicitar" en la pagina.
  5. Al detectar el cambio de URL al estado "en_progreso", captura el link de tracking.
  6. POST de vuelta a Odoo (callback) con el link.

Pensado para correr en Windows con autostart.

Antes del primer uso:
  - py -m pip install -r requirements.txt
  - py -m playwright install chromium
  - Editar config.json con la URL de Odoo callback y datos de la sucursal.
  - Primer arranque: abrir Chrome controlado y loguear uber.com manualmente
    (la sesion queda guardada en ./chrome_profile/).
"""

import json
import logging
import os
import re
import threading
import time
from pathlib import Path
from urllib.parse import quote

import requests
from flask import Flask, jsonify, request

# Playwright se carga lazy en el thread del worker
PLAYWRIGHT = None
BROWSER_CTX = None

ROOT = Path(__file__).parent
CONFIG_PATH = ROOT / "config.json"
PROFILE_DIR = ROOT / "chrome_profile"
LOG_PATH = ROOT / "bridge.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler()],
)
log = logging.getLogger("uber-bridge")

CONFIG = {}
if CONFIG_PATH.exists():
    CONFIG = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

UBER_SEND_URL = "https://m.uber.com/go/product-selection"
TRACKING_URL_RE = re.compile(r"https?://(?:m|trip)\.uber\.com/[^\s\"'<>]+")
QUEUE: "list[dict]" = []
QUEUE_LOCK = threading.Lock()


# ----------------------------------------------------------------------------
# HTTP API
# ----------------------------------------------------------------------------
app = Flask(__name__)


@app.get("/health")
def health():
    return jsonify({"ok": True, "version": "1.0.0", "queue_len": len(QUEUE)})


@app.post("/solicitar")
def solicitar():
    payload = request.get_json(force=True, silent=True) or {}
    required = ["envio_id", "direccion", "origen_direccion"]
    missing = [k for k in required if not payload.get(k)]
    if missing:
        return jsonify({"error": f"Faltan campos: {missing}"}), 400

    log.info("Recibido envio %s -> %s", payload.get("envio_ref"), payload.get("direccion"))
    with QUEUE_LOCK:
        QUEUE.append(payload)
    return jsonify({"ok": True, "encolado": True}), 200


@app.post("/cancelar")
def cancelar():
    """Quita un envio de la cola si todavia no se proceso."""
    payload = request.get_json(force=True, silent=True) or {}
    envio_id = payload.get("envio_id")
    with QUEUE_LOCK:
        antes = len(QUEUE)
        QUEUE[:] = [p for p in QUEUE if p.get("envio_id") != envio_id]
        quitado = antes - len(QUEUE)
    return jsonify({"quitado": quitado})


# ----------------------------------------------------------------------------
# Worker que opera Playwright
# ----------------------------------------------------------------------------
def worker_loop():
    from playwright.sync_api import sync_playwright

    log.info("Worker iniciado. Profile: %s", PROFILE_DIR)
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE_DIR),
            headless=False,
            channel="chrome",  # usa Chrome instalado
            viewport={"width": 1280, "height": 820},
            args=["--disable-blink-features=AutomationControlled"],
        )
        # Mantenemos al menos una pagina abierta
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto("about:blank")

        while True:
            payload = None
            with QUEUE_LOCK:
                if QUEUE:
                    payload = QUEUE.pop(0)
            if payload:
                try:
                    procesar(ctx, payload)
                except Exception as e:
                    log.exception("Error procesando envio: %s", e)
                    callback_odoo(payload, error=str(e), estado="error")
            else:
                time.sleep(2)


def procesar(ctx, payload):
    """Abre uber.com con datos precargados para que el cajero confirme."""
    page = ctx.new_page()
    origen = payload.get("origen_direccion") or ""
    destino = payload.get("direccion") or ""
    if payload.get("ciudad"):
        destino = f"{destino}, {payload['ciudad']}"

    # Uber Send (envios) tiene una URL con query params de pickup/dropoff.
    # Si la URL exacta cambia, el cajero igual la completa a mano.
    url = (
        f"{UBER_SEND_URL}?"
        f"pickup={quote(origen)}"
        f"&drop[0]={quote(destino)}"
        f"&product=delivery"
    )
    log.info("Abriendo Uber: %s", url)
    page.goto(url, wait_until="domcontentloaded", timeout=30000)

    # Banner visible al cajero con info del envio
    page.evaluate(
        """(data) => {
            const b = document.createElement('div');
            b.id = 'petland-banner';
            b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#FF7A00;color:#fff;padding:12px 18px;font:600 16px sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.2);';
            b.innerHTML = `<b>Pet Land - Envio #${data.envio_ref}</b> &middot; ${data.cliente} (${data.telefono||'-'}) &middot; <b>${data.lo_paga_cliente?'Cobrar al cliente':'GRATIS - lo paga Pet Land'}</b> &middot; Compra: $${data.monto}`;
            document.body && document.body.prepend(b);
        }""",
        {
            "envio_ref": payload.get("envio_ref"),
            "cliente": payload.get("cliente"),
            "telefono": payload.get("telefono"),
            "lo_paga_cliente": payload.get("lo_paga_cliente"),
            "monto": payload.get("monto"),
        },
    )

    # Esperar a que el cajero confirme. Polleamos URL + DOM por el tracking link
    # hasta 15 minutos (timeout amplio porque puede haber cola de cajeros).
    link_tracking = esperar_tracking(page, timeout_seg=900)
    if link_tracking:
        log.info("Tracking link capturado: %s", link_tracking)
        callback_odoo(payload, link_tracking=link_tracking, estado="solicitando")
    else:
        log.warning("No se detecto tracking link en 15min para envio %s", payload.get("envio_ref"))
        callback_odoo(payload, estado="error",
                       error="Timeout: el cajero no confirmo en 15 min")

    # Dejamos la pestaña abierta unos minutos por si el cajero quiere revisar
    threading.Timer(120, lambda: page.close() if not page.is_closed() else None).start()


def esperar_tracking(page, timeout_seg=900):
    """Pollea cada 3s buscando un link de tracking en URL, en el DOM o en el clipboard."""
    deadline = time.time() + timeout_seg
    seen_urls = set()
    while time.time() < deadline:
        try:
            # 1. URL actual
            current_url = page.url
            m = TRACKING_URL_RE.search(current_url)
            if m and "trip" in m.group():
                return m.group()

            # 2. Texto/HTML completo
            html = page.content()
            for m in TRACKING_URL_RE.finditer(html):
                u = m.group()
                if u in seen_urls:
                    continue
                seen_urls.add(u)
                # Filtramos URLs de tracking reales (suelen ser m.uber.com/trip o trip.uber.com)
                if "/trip" in u or "trip.uber.com" in u or "/share" in u:
                    return u
        except Exception:
            pass
        time.sleep(3)
    return None


def callback_odoo(payload, link_tracking=None, costo=None, estado=None, error=None):
    callback = payload.get("callback_url") or CONFIG.get("odoo_callback_url")
    if not callback:
        log.error("Sin callback_url, no aviso a Odoo. Envio %s", payload.get("envio_ref"))
        return
    body = {"params": {"envio_id": payload.get("envio_id")}}
    if link_tracking:
        body["params"]["link_tracking"] = link_tracking
    if costo is not None:
        body["params"]["costo"] = costo
    if estado:
        body["params"]["estado"] = estado
    if error:
        body["params"]["error"] = error
    try:
        # Odoo JSON-RPC espera Content-Type: application/json y wrapper {params: ...}
        r = requests.post(callback, json=body, timeout=15)
        log.info("Callback Odoo %s -> %s", callback, r.status_code)
    except Exception as e:
        log.error("Fallo callback Odoo: %s", e)


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    PROFILE_DIR.mkdir(exist_ok=True)
    t = threading.Thread(target=worker_loop, daemon=True)
    t.start()
    port = int(CONFIG.get("port", 5005))
    log.info("Bridge escuchando en http://0.0.0.0:%s", port)
    app.run(host="0.0.0.0", port=port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
